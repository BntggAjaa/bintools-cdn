import fs from 'fs'

// settings bot
global.namaown = "Lirzan"
global.owner = ["6285871019341"]
global.session = "sessions"

// TAMBAHKAN INI (ganti dengan key baru)
global.groqKey = "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"
global.geminiKey = "AQ.Ab8RN6ITTrqVzVyfqktyimng6qYmxGqp0dTM8dekQvmWDoYEgw"